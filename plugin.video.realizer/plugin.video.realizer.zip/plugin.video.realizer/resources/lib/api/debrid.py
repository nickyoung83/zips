# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import time
import urllib.request
import urllib.parse
import urllib.error
import xbmc

import requests

from resources.lib.modules import cleantitle, clipboard, control, utils

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])

USER_AGENT = 'RealDebrid Addon for Kodi'
# data = {}
# params = {}
VALID_EXT = ['mkv', 'avi', 'mp4', 'divx', 'mpeg', 'mov', 'wmv', 'avc', 'mk3d', 'xvid', 'mpg', 'flv', 'aac', 'asf', 'm4a', 'm4v', 'mka', 'ogg', 'oga', 'ogv', 'ogx', '3gp', 'vivo', 'pva', 'flc']
requestTimeout = 30
EXT_BLACKLIST = ['rar.html', '.php', '.txt', '.iso', '.zip', '.rar', '.jpeg', '.img', '.jpg', '.RAR', '.ZIP', '.png', '.sub', '.srt']

# #############################################################################
# ################################ REAL DEBRID ################################
# #############################################################################


def save_json(client_id=None, client_secret=None, token=None, refresh_token=None, expires_in=None):
    if not os.path.exists(control.dataPath): os.makedirs(control.dataPath)
    if token is not None: data = {'client_id':client_id, 'client_secret':client_secret, 'token':token, 'refresh_token':refresh_token, 'added':control.timeNow}
    else: data = {'client_id':client_id, 'client_secret':client_secret, 'token':'0', 'refresh_token': '0', 'added':control.timeNow}
    with open(control.rdauthFile, 'w') as outfile: json.dump(data, outfile, indent=2)


def list_downloads():
    r = RealDebrid().list_downloads()

    try:
        for result in r:
            try:
                cm = []
                icon = result['host_icon']
                name = result['filename']
                name = normalize(name)
                id = result['id']
                link = result['link']
                ext = name.split('.')[-1]

                isPlayable = ext in VALID_EXT
                isPlayable = not isPlayable

                label = ext.upper() + " | " + name

                item = control.item(label=label)
                item.setArt({'icon': icon, 'thumb': icon})
                item.setProperty('Fanart_Image', control.addonFanart())

                infolabel = {"Title": name}
                item.setInfo(type='Video', infoLabels = infolabel)
                item.setProperty('IsPlayable', 'true')

                url = result['download']
                cm.append(('Delete Download Item', 'RunPlugin(%s?action=rdDeleteItem&id=%s&type=downloads)' % (sysaddon, id)))
                if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s&id=%s)' % (sysaddon, name, url, id)))
                item.addContextMenuItems(cm)
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
            except: pass
    except: pass

    control.content(syshandle, 'movies')
    control.directory(syshandle, cacheToDisc=True)


# def list_torrents():
    # r = RealDebrid().list_torrents()

    # if control.setting('sort.torrents') == 'true':
        # try: r = sorted(r, key=lambda k: utils.title_key(k['filename']))
        # except: pass

    # for item in r:
        # cm = []
        # status = item['status']
        # id = item['id']
        # name = item['filename']
        # label = status.upper() + " | " + name
        # item = control.item(label=label)
        # item.setArt({'icon': control.addonIcon()})
        # item.setProperty('Fanart_Image', control.addonFanart())
        # infolabel = {"Title": label}
        # cm.append(('Delete Torrent Item', 'RunPlugin(%s?action=rdDeleteItem&id=%s&type=torrents)' % (sysaddon, id)))
        # url = '%s?action=%s&id=%s' % (sysaddon, 'rdTorrentInfo', id)
        # item.addContextMenuItems(cm)
        # control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)

    # control.directory(syshandle, cacheToDisc=True)


def torrent_info(id):
    r = RealDebrid().torrent_info(id)
    links = r['links']
    files = r['files']
    try: files = sorted(files, key=lambda k: utils.title_key(k['path']))
    except: pass
    count = 0
    for x in files:
        try:
            oriGinalName = x['path']
            if oriGinalName.startswith('/'):
                name = oriGinalName.split('/')[-1]

            ext = name.split('.')[-1]
            isPlayable = ext in VALID_EXT
            if ext.lower() not in VALID_EXT: raise Exception()
            label = ext.upper() + " | " + name

            item = control.item(label=label)
            item.setArt({'icon': control.addonIcon()})
            item.setProperty('Fanart_Image', control.addonFanart())
            infolabel = {"Title": name}
            item.setInfo(type='Video', infoLabels = infolabel)
            item.setProperty('IsPlayable', 'true')
            systitle = urllib.parse.quote_plus(name)
            url = '%s?action=%s&name=%s&id=%s' % (sysaddon, 'play_torrent_item', systitle, id)
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
        except: pass

    control.content(syshandle, 'movies')
    control.directory(syshandle, cacheToDisc=True)


def play_torrent_item(name, id):
    torrInDownload = []
    try : name = name.split('/')[-1]
    except: name = name
    try:
        downloads = RealDebrid().list_downloads()
        torrInDownload = [i for i in downloads if i['filename'].lower() == name.lower()][0]
    except: pass

    if len(torrInDownload) > 0:
        item = control.item(label=name)
        item.setArt({'icon': control.addonIcon()})
        item.setProperty('Fanart_Image', control.addonFanart())
        infolabel = {"Title": name}
        item.setInfo(type='Video', infoLabels = infolabel)
        item.setProperty('IsPlayable', 'true')
        item = control.item(path= torrInDownload['download'])

        control.resolve(int(sys.argv[1]), True, item)

    else:
        newTorr = []

        try:
            result = torrent_item_to_download(name, id)
            if result != None: newTorr.append(result)
        except: pass

        time.sleep(1)

        torrItem = newTorr[0]

        if len(torrItem) > 0:
            control.infoDialog('Playing Torrent Item', torrItem['filename'], time=3)
            item = control.item(label=name)
            item.setArt({'icon': control.addonIcon()})
            item.setProperty('Fanart_Image', control.addonFanart())
            infolabel = {"Title": name}
            item.setInfo(type='Video', infoLabels = infolabel)
            item.setProperty('IsPlayable', 'true')
            item = control.item(path= torrItem['download'])
            control.resolve(int(sys.argv[1]), True, item)


def torrent_item_to_download(name, id):
    torrInDownload = []
    torrItem = []
    FileMatch = False
    try:
        r = RealDebrid().torrent_info(id)
        links = r['links']
        files = r['files']
        newTorr = []

        count = 0
        for x in files:
            try:
                itemID = x['id']
                itemName = x['path']

                ext = itemName.split('.')[-1]
                if not ext.lower() in VALID_EXT: raise Exception()

                playlink = links[count]
                count += 1

                fileName = itemName
                try: fileName = fileName.split('/')[-1]
                except: pass

                origName = name
                try: origName = origName.split('/')[-1]
                except: pass

                if not cleantitle.get(fileName) == cleantitle.get(origName): raise Exception()
                result = RealDebrid().resolve(playlink, full=True)
                if result != None: newTorr.append(result)
            except: pass

        time.sleep(1)
        torrItem = newTorr

        if len(torrItem) > 0:
            for x in torrItem:
                fileName = x['filename']
                try: fileName = fileName.split('/')[-1]
                except: pass

                origName = name
                try: origName = origName.split('/')[-1]
                except: pass
                if cleantitle.get(fileName) == cleantitle.get(origName):
                    FileMatch = True
                    return x

        if FileMatch is False:  #FALLBACK TO UNRESTRICT ALL PACK
            for y in links:
                try:
                    result_2 = RealDebrid().resolve(y, full=True)
                    newFileName = result_2['filename']
                    try: newFileName = newFileName.split('/')[-1]
                    except: pass
                    origName = name
                    try: origName = origName.split('/')[-1]
                    except: pass

                    if cleantitle.get(newFileName) == cleantitle.get(origName):
                        FileMatch = True
                        return result_2

                    RealDebrid().delete_list_item(result_2['id'])
                except: pass
    except: return []


def normalize(txt):
    txt = re.sub(r'[^\x00-\x7f]',r'', txt)
    return txt


class RealDebrid:
    def __init__(self):
        self.RealDebridApi = 'https://api.real-debrid.com/rest/1.0'
        self.RD_APINAME = 'Realizer'
        self.RD_CLIENTID = 'X245A4XAIBGVM'
        self.RD_OAUTH = 'https://api.real-debrid.com/oauth/v2/device/code?client_id=%s&new_credentials=yes' % self.RD_CLIENTID
        self.RD_TOKEN_AUTH = 'https://api.real-debrid.com/oauth/v2/token'
        self.RD_CREDENTIALS_AUTH = 'https://api.real-debrid.com/oauth/v2/device/credentials?client_id=%s&code=%s'
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'
        # self.transfers = []
        # self.torrents = []


    def auth(self):
        result = requests.get(self.RD_OAUTH, timeout=requestTimeout).json()
        expires_in = int(result['expires_in'])
        device_code = result['device_code']
        interval = int(result['interval'])
        message = ('1) Visit:[B][COLOR skyblue] {url} [/COLOR][/B] \n'
                   '2) Input Code:[B][COLOR skyblue] {code} [/COLOR][/B] \n \n'
                   'Note: Your code has been copied to the clipboard'
                  ).format(url=result['verification_url'], code=result['user_code'])
        # message = '\n'.join([verification_url, user_code, line3])

        try: clipboard.Clipboard.copy(result['user_code'])
        except: pass

        control.progressDialog.create('Real Debrid', message)

        for i in range(0, expires_in):
            try:
                if control.progressDialog.iscanceled(): break
                time.sleep(1)
                if not float(i) % interval == 0: raise Exception()

                percent = int(float((i * 100) / expires_in))
                control.progressDialog.update(percent, message)

                credentials = self.get_credentials(device_code)
                if "client_secret" not in str(credentials): raise Exception()

                client_secret = credentials["client_secret"]
                client_id = credentials["client_id"]
                r = self.get_auth(self.RD_TOKEN_AUTH , client_id, client_secret, device_code)

                if "access_token" in str(r):
                    token = r["access_token"]
                    refresh_token = r["refresh_token"]
                    save_json(token=token, client_id=client_id, client_secret=client_secret, refresh_token=refresh_token)
                    control.infoDialog("RealDebrid Authorised")

                    try: control.progressDialog.close()
                    except: pass

                    return token
                    break
            except:
                pass
        try: control.progressDialog.close()
        except: pass


    def get_credentials(self, device_code):
        url = self.RD_CREDENTIALS_AUTH % (self.RD_CLIENTID, device_code)
        result = requests.get(url, timeout=5).json()
        return result


    def get_auth(self, url, client_id, client_secret, device_code):
        headers = {"User-Agent": self.USER_AGENT}
        data = {"client_id": client_id, "client_secret": client_secret, "code": device_code, "grant_type": 'http://oauth.net/grant_type/device/1.0'}
        result = requests.post(url, data=data, headers=headers, timeout=requestTimeout).json()
        return result


    def refresh_rd_token(self, refresh_token, client_secret, client_id):
        headers = {'User-Agent': self.USER_AGENT}
        data = {'client_id': client_id, 'client_secret': client_secret, 'code': refresh_token, 'grant_type': 'http://oauth.net/grant_type/device/1.0'}
        result = requests.post(self.RD_TOKEN_AUTH, data=data, headers=headers, timeout=requestTimeout).json()
        if 'access_token' in str(result):
            # expires_in = result['expires_in']
            token = result['access_token']
            refresh_token = result['refresh_token']
            # print ("REFRESHING TOKEN", token)
            save_json(token=token, client_secret=client_secret, client_id=client_id, refresh_token=refresh_token)
            return token


    def get_token(self, refresh=False):
        token = '0'
        if not os.path.exists(control.rdauthFile):
            save_json()
            return
        if refresh:
            try:
                with open(control.rdauthFile) as json_file:
                    try:
                        data = json.load(json_file)
                        refresh_token = data['refresh_token']
                        client_id = data['client_id']
                        client_secret = data['client_secret']
                        token = self.refresh_rd_token(refresh_token, client_secret, client_id)
                    except: token = None
                if token == '' or token is None or token == '0': control.infoDialog('Real Debrid is not Authorised','Please authorise in the settings')
            except: pass
        else:
            try:
                with open(control.rdauthFile) as json_file:
                    try:
                        data = json.load(json_file)
                        token = data['token']
                    except: token = None
                if token == '' or token is None or token == '0': control.infoDialog('Real Debrid is not Authorised','Please authorise in the settings')
            except: pass
        if token == '' or token is None: token = '0'
        return token


    def account_info(self):
        token = '0'
        if not os.path.exists(control.rdauthFile): save_json()
        try:
            with open(control.rdauthFile) as json_file:
                try:
                    data = json.load(json_file)
                    token = data['token']
                except: token = None

        except: pass
        if token == '' or token is None or token == '0': return False
        else: return True


    def rd_request(self, url, method='get', data=None, params=None, refresh=False):
        token = self.get_token(refresh=refresh)
        headers = {'Authorization': 'Bearer %s' % token, 'client_id': self.RD_CLIENTID, 'User-Agent': self.USER_AGENT}
        try:
            if method == 'get': result = requests.get(url, headers=headers, params=params, timeout=requestTimeout)
            elif method == 'post': result = requests.post(url, headers=headers, data=data, timeout=requestTimeout)
            elif method == 'delete': result = requests.delete(url, headers=headers, data=data, timeout=requestTimeout)
        except requests.Timeout as err: control.infoDialog('REALDEBRID TIMED OUT', time=3)
        if result.status_code == 401:
            if not refresh:
                result = self.rd_request(url, method=method, data=data, refresh=True)
                return result
            else: return result
        else:
            return result


    def list_downloads(self):
        url = self.RealDebridApi + '/downloads'
        params = {'limit': 100}
        result = self.rd_request(url, method='get', params=params).json()
        return result


    def list_torrents(self):
        url = self.RealDebridApi + '/torrents'
        params = {'limit': 100}
        result = self.rd_request(url, method='get', params=params).json()
        # return result

        r = result

        if control.setting('sort.torrents') == 'true':
            try: r = sorted(r, key=lambda k: utils.title_key(k['filename']))
            except: pass

        for item in r:
            cm = []
            status = item['status']
            id = item['id']
            name = item['filename']
            label = status.upper() + " | " + name
            item = control.item(label=label)
            item.setArt({'icon': control.addonIcon()})
            item.setProperty('Fanart_Image', control.addonFanart())
            infolabel = {"Title": label}
            cm.append(('Delete Torrent Item', 'RunPlugin(%s?action=rdDeleteItem&id=%s&type=torrents)' % (sysaddon, id)))
            url = '%s?action=%s&id=%s' % (sysaddon, 'rdTorrentInfo', id)
            item.addContextMenuItems(cm)
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)

        control.directory(syshandle, cacheToDisc=True)


    def torrent_info(self, id):
        url = self.RealDebridApi + '/torrents/info/' + id
        result = self.rd_request(url, method='get').json()
        return result


    def delete_list_item(self, id, type):
        try:  # DOWNLOADS
            if type != 'downloads': raise Exception()
            d = '/downloads/delete/%s' % id
            delete = self.RealDebridApi + d
            result = self.rd_request(delete, method='delete').json()
        except:
            pass

        try: # TORRENTS
            if type != 'torrents': raise Exception()
            d = '/torrents/delete/%s' % id
            delete = self.RealDebridApi + d
            result = self.rd_request(delete, method='delete').json()
        except:
            pass


    def resolve(self, url, full=False):
        if url.startswith("//"): url = 'http:' + url
        try:
            post = {'link': url}
            url = self.RealDebridApi + '/unrestrict/link'
            result = self.rd_request(url, method='post', data=post).json()
            if 'error_code' in str(result): return None
            if full is True: return result
            try: url = result['download']
            except: return None
            if url.startswith('//'): url = 'http:' + url
            return url
        except:
            pass

